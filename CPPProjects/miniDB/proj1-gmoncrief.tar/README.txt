README for project 1

1.	unzip the files into an empty folder. Contents should include:
	*	P1.cpp
	*	coaches.h
	*	teams.h
	*	README.txt

2.	add any neccessary txt files for coaches and team

3.	navigate to folder and compile with g++ *.cpp -std=c++11

4.	./a.out will run the database